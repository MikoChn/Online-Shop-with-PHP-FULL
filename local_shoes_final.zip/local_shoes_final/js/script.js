// Function to validate the login form
function validateLoginForm(event) {
    event.preventDefault();
  
    // Retrieve input values
    var username = document.getElementById("login-username").value;
    var password = document.getElementById("login-password").value;
  
    // Validate username and password (add your own validation logic)
    if (username === "admin" && password === "password") {
      alert("Login successful");
      // Redirect to the appropriate page
    } else {
      alert("Invalid username or password");
    }
  }
  
  // Function to validate the registration form
  function validateRegisterForm(event) {
    event.preventDefault();
  
    // Retrieve input values
    var username = document.getElementById("register-username").value;
    var password = document.getElementById("register-password").value;
    var confirmPassword = document.getElementById("register-confirm-password").value;
    var email = document.getElementById("register-email").value;
    var address = document.getElementById("register-address").value;
  
    // Validate username and password (add your own validation logic)
    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }
  
    // Validate email format using regular expression
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      alert("Invalid email address");
      return;
    }
  
    // Perform additional validation if needed
    // ...
  
    // Registration successful, submit the form or perform further actions
    alert("Registration successful");
    // Submit the form or redirect to the appropriate page
  }
  