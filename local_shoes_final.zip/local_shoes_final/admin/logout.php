<?php 
	
	session_destroy();
	echo "<script>alert('Anda Berhasil Log Out');</script>";
	echo "<script>location = 'login.php';</script>";
 ?>