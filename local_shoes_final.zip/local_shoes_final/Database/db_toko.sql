-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Jul 2023 pada 15.09
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_toko`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `provinsi`
--

CREATE TABLE `provinsi` (
  `id_prov` char(2) NOT NULL,
  `nama` tinytext NOT NULL,
  `ongkir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `provinsi`
--

INSERT INTO `provinsi` (`id_prov`, `nama`, `ongkir`) VALUES
('11', 'Aceh', 20000),
('12', 'Sumatera Utara', 19500),
('13', 'Sumatera Barat', 19500),
('14', 'Riau', 20000),
('15', 'Jambi', 18000),
('16', 'Sumatera Selatan', 19500),
('17', 'Bengkulu', 18000),
('18', 'Lampung', 19000),
('19', 'Kepulauan Bangka Belitung', 20000),
('21', 'Kepulauan Riau', 20000),
('31', 'DKI Jakarta', 18000),
('32', 'Jawa Barat', 15000),
('33', 'Jawa Tengah', 12000),
('34', 'DI Yogyakarta', 12000),
('35', 'Jawa Timur', 10000),
('36', 'Banten', 15000),
('51', 'Bali', 20000),
('52', 'Nusa Tenggara Barat', 25000),
('53', 'Nusa Tenggara Timur', 25000),
('61', 'Kalimantan Barat', 20000),
('62', 'Kalimantan Tengah', 22000),
('63', 'Kalimantan Selatan', 22000),
('64', 'Kalimantan Timur', 23000),
('65', 'Kalimantan Utara', 23000),
('71', 'Sulawesi Utara', 25000),
('72', 'Sulawesi Tengah', 25000),
('73', 'Sulawesi Selatan', 25000),
('74', 'Sulawesi Tenggara', 25000),
('75', 'Gorontalo', 22000),
('76', 'Sulawesi Barat', 25000),
('81', 'Maluku', 25000),
('82', 'Maluku Utara', 25000),
('91', 'Papua Barat', 30000),
('92', 'Papua', 30000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `username`, `password`, `nama`) VALUES
(1, 'admin', 'admin', 'Teguh Kurniawan'),
(2, 'Pandu', 'admin', 'Agung Pandu Widjanarko');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `telepon` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`id_pelanggan`, `email`, `password`, `nama_pelanggan`, `telepon`) VALUES
(11, 'a@gmail.com', '12345', 'agrt', '243'),
(15, 'dila@gmail.com', '12345', 'dila', '123456'),
(16, '', '', '', ''),
(17, '', '', '', ''),
(18, '', '', '', ''),
(19, 'agungpandu@gmail.com', '12345', 'agung pandu', '081290159603');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pembayaran`
--

CREATE TABLE `tb_pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `bank` varchar(30) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pembayaran`
--

INSERT INTO `tb_pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti`) VALUES
(3, 17, 'Teguh Kurniawan', 'BCA', 200000, '2019-07-03', '20190703061724bukti1.jpg'),
(4, 16, 'USER', 'BCA', 200000, '2019-07-03', '20190703062611bukti2.jpg'),
(6, 21, 'agung pandu', 'bca ', 1000000, '2023-07-10', '20230710120727'),
(7, 21, '', '', 0, '2023-07-10', '20230710121133'),
(8, 22, '', '', 0, '2023-07-10', '20230710123240'),
(9, 22, '', '', 0, '2023-07-10', '20230710123324'),
(10, 22, '', '', 0, '2023-07-10', '20230710123947'),
(11, 38, '', '', 0, '2023-07-10', '20230710124133'),
(12, 38, 'asd', '12222', 1, '2023-07-10', '20230710124307'),
(13, 39, '', '', 0, '2023-07-10', '20230710125301'),
(14, 42, 'agung pandu', 'bca', 1542000, '2023-07-10', '20230710010801discount.png'),
(15, 42, 'agung', 'bca', 1542000, '2023-07-10', '20230710011107discount.png'),
(16, 43, 'agung', 'bca', 200000, '2023-07-10', '20230710011811f3.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pembelian`
--

CREATE TABLE `tb_pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `tarif` int(11) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pembelian`
--

INSERT INTO `tb_pembelian` (`id_pembelian`, `id_pelanggan`, `id_prov`, `tanggal_pembelian`, `total_pembelian`, `tarif`, `alamat`, `status`) VALUES
(16, 3, 34, '2019-07-02', 62000, 12000, 'Jl.Ambai', 'Produk di Terima'),
(17, 3, 91, '2019-07-02', 285000, 30000, 'Jl.Kartanegara Gg Cempaka No.108B ', 'Menunggu Konfirmasi'),
(18, 3, 16, '2019-07-07', 449500, 19500, 'Jl.Gunung Merapi', 'Menunggu Konfirmasi'),
(19, 3, 53, '2019-07-07', 275000, 25000, 'Jl.Patimmura No 91', 'Pending'),
(21, 11, 11, '2023-07-08', 145000, 20000, 'jl jatisati raya', 'Produk di Terima'),
(22, 11, 12, '2023-07-08', 144500, 19500, 'jl sinaraga', 'Sedang di Kirim'),
(38, 11, 0, '2023-07-10', 1200000, 0, '', 'Sedang di Kirim'),
(39, 11, 0, '2023-07-10', 200000, 0, '', 'Menunggu Konfirmasi'),
(40, 11, 0, '2023-07-10', 230000, 0, '', 'Pending'),
(41, 11, 0, '2023-07-10', 200000, 0, '', 'Pending'),
(42, 19, 32, '2023-07-10', 1542000, 15000, 'jln cendrawasih a1 jakamulya Bekasi Selatan', 'Sedang di Kirim'),
(43, 19, 11, '2023-07-10', 140000, 20000, '', 'Produk di Terima');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pembelian_produk`
--

CREATE TABLE `tb_pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pembelian_produk`
--

INSERT INTO `tb_pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`) VALUES
(23, 16, 10, 1),
(24, 17, 1, 1),
(25, 18, 1, 1),
(26, 18, 8, 1),
(27, 19, 9, 1),
(29, 21, 16, 1),
(30, 22, 16, 1),
(31, 23, 16, 1),
(32, 24, 16, 1),
(33, 24, 17, 1),
(34, 24, 23, 1),
(35, 24, 18, 1),
(36, 25, 17, 3),
(37, 25, 19, 1),
(38, 25, 16, 1),
(39, 26, 17, 1),
(40, 27, 16, 1),
(41, 28, 21, 1),
(42, 29, 16, 1),
(43, 30, 16, 1),
(44, 31, 16, 1),
(45, 32, 16, 1),
(46, 33, 17, 1),
(47, 33, 18, 1),
(48, 33, 19, 4),
(49, 34, 21, 1),
(50, 35, 17, 1),
(51, 36, 21, 5),
(52, 37, 19, 1),
(53, 37, 20, 1),
(54, 37, 18, 4),
(55, 38, 19, 2),
(56, 38, 20, 3),
(57, 39, 17, 1),
(58, 40, 18, 1),
(59, 41, 17, 1),
(60, 42, 18, 1),
(61, 42, 22, 3),
(62, 42, 17, 5),
(63, 43, 21, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_produk`
--

CREATE TABLE `tb_produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(40) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `foto_produk` varchar(40) NOT NULL,
  `deskripsi_produk` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_produk`
--

INSERT INTO `tb_produk` (`id_produk`, `nama_produk`, `harga_produk`, `berat_produk`, `foto_produk`, `deskripsi_produk`) VALUES
(17, 'Compass High Hitam', 200000, 250, 'f4.png', 'Compass-High Hitam \r\n“now everyone can buy a good shoe”\r\nCocok untuk para kalangan muda yang masih bersekolah \r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm\r\n\r\n'),
(18, 'Compass-Low White Grey', 230000, 210, 'f3.png', 'Compass-Low Black Grey\r\nBack To School\r\n\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm\r\n“now everyone can buy a good shoe”'),
(19, 'Compas-Low Black Grey', 300000, 220, 'f1.png', 'Compas-Low Black Grey\r\nSemangat Sekolah with Compas\r\n\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm\r\n\r\n'),
(20, 'AeroXSwall-Low HXP', 200000, 240, 'aerostreethitamswallow.png', 'AerostreetXSwallow-Low HXP\r\nkolaborasi antara brand Aerostreet dan Swallow\r\n\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm\r\n'),
(21, 'Aerostreet-High White', 120000, 200, 'aerocolor.png', 'Aerostreet-High White\r\nKalangan Wanita muda yang gemar berolahraga!!\r\n\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm'),
(22, 'AeroStreet-Low TSY', 99000, 199, 'aero-low.png', 'AeroStreet-Low TSY\r\nFancy Shoes for only 99k!\r\n\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm'),
(23, 'AeroXSwall-Low Merah', 200000, 210, 'aerostreetmerah-removebg.png', 'AerostreetXSwallow low Merah \r\nKolaborasi Brand AerostreetXSwallow Red Edition\r\n\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm'),
(25, 'Compass-BlackWhite', 220000, 210, 'f2.png', 'Compass-BlackWhite\r\nmewujudkan impian terdahulu, menggabungkan kesan vintage dengan teknologi yang modern.\r\nPanduan ukuran :\r\nUkuran 36 Panjang telapak kaki 23,4 cm\r\nUkuran 37 Panjang telapak kaki 24,0 cm\r\nUkuran 38 Panjang telapak kaki 24,7 cm\r\nUkuran 39 Panjang telapak kaki 25,3 cm\r\nUkuran 40 Panjang telapak kaki 26,0 cm\r\nUkuran 41 Panjang telapak kaki 26,6 cm\r\nUkuran 42 Panjang telapak kaki 27,3 cm\r\nUkuran 43 Panjang telapak kaki 28,0 cm\r\nUkuran 44 Panjang telapak kaki 28,7 cm\r\nUkuran 45 Panjang telapak kaki 29,3 cm');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`id_prov`);

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indeks untuk tabel `tb_pembelian`
--
ALTER TABLE `tb_pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indeks untuk tabel `tb_pembelian_produk`
--
ALTER TABLE `tb_pembelian_produk`
  ADD PRIMARY KEY (`id_pembelian_produk`);

--
-- Indeks untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `tb_pembelian`
--
ALTER TABLE `tb_pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT untuk tabel `tb_pembelian_produk`
--
ALTER TABLE `tb_pembelian_produk`
  MODIFY `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
